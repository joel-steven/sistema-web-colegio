import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, normalize, resolve } from 'node:path';
const root=resolve('.'),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
createServer(async(req,res)=>{try{let path=decodeURIComponent(req.url.split('?')[0]).replace(/^\//,'')||'index.html';if(path.endsWith('/'))path+='index.html';path=normalize(path);const file=resolve(root,path);if(!file.startsWith(root))throw new Error();const body=await readFile(file);res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream'});res.end(body);}catch{res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('No encontrado');}}).listen(4173,()=>console.log('EduNova local: http://localhost:4173'));
