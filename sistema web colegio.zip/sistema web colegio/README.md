# EduNova — primera etapa

Base web estática para un sistema académico, construida con HTML, CSS, JavaScript modular y Firebase (Auth, Firestore y Storage). El acceso, la recuperación de contraseña, la redirección por rol y la gestión académica funcionan realmente al configurar Firebase.

## Estructura

```text
admin/ profesor/ padre/             Portales protegidos por rol
assets/css/main.css                 Diseño responsive compartido
assets/js/auth/                     Pantalla de acceso
assets/js/components/               Layout, tarjetas y datos de demostración
assets/js/config/                   Inicialización y credenciales Firebase
assets/js/services/                 Servicios reutilizables de Firebase
assets/js/admin/academic-modules.js CRUD académico real del administrador
firestore.rules                     Punto inicial de reglas de seguridad
firestore.indexes.json              Índice para futuras consultas de notas
```

## Configurar Firebase

1. Cree un proyecto Firebase y registre una aplicación web.
2. Active **Authentication > Correo electrónico/contraseña**.
3. Cree Cloud Firestore y pegue `firestore.rules` e `firestore.indexes.json` desde la consola o Firebase CLI.
4. Copie la configuración de la aplicación web en `assets/js/config/firebase-config.js`.
5. Cree cada usuario en Authentication y su documento correspondiente en `usuarios/{UID}`. Campos mínimos: `rol` (`administrador`, `profesor` o `padre`), `nombre`, `email`, `activo`.
6. Publique con Firebase Hosting. Para desarrollo local, sirva la carpeta con un servidor HTTP; no abra los HTML como archivos locales.

## Modelo base Firestore

Colecciones previstas: `usuarios`, `estudiantes`, `apoderados`, `docentes`, `grados`, `secciones`, `cursos`, `asignaciones`, `periodos`, `evaluaciones`, `notas`, `asistencias`, `matriculas`, `conceptos_pago`, `pagos`, `comunicados`, `notificaciones`, `justificaciones`, `configuracion`.

Las colecciones activas son: `anios_academicos`, `periodos`, `grados`, `secciones`, `cursos`, `docentes`, `estudiantes`, `matriculas` y `asignaciones`. Una matrícula conserva los IDs de estudiante, año, grado y sección. Una asignación conserva año, grado, sección, curso y docente. La futura colección `notas` deberá guardar `estudianteId`, `matriculaId`, `asignacionId`, `cursoId`, `docenteId`, `periodoId`, `evaluacionId`, `anioId`, `valor`, `fecha`, `registradoPorUid` y `modificadoPorUid`.

## Alcance actual

Funciona: login Firebase, recuperación, logout, sesión protegida, lectura de rol y redirección a los tres portales. El administrador puede crear, editar, buscar, activar/desactivar y consultar la estructura académica real. También se validan duplicados, fechas de períodos, matrículas y asignaciones. El contenido de los dashboards es demostrativo y los accesos al módulo de notas indican claramente que quedan reservados para la siguiente etapa. Aún no se guardan notas, asistencias ni pagos.
