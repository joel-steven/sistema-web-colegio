import { readStore, writeStore, newId } from '../data/local-store.js';
export const COLLECTIONS=['anios_academicos','periodos','grados','secciones','cursos','docentes','apoderados','estudiantes','matriculas','asignaciones'];
const rows=(name,sort)=>[...(readStore()[name]||[])].sort((a,b)=>String(a[sort]??'').localeCompare(String(b[sort]??'')));
export const getAll=async(name,sort='nombre')=>rows(name,sort);
export const watchAll=(name,callback,sort='nombre')=>{const update=()=>callback(rows(name,sort));update();window.addEventListener('edunova-local-change',update);return()=>window.removeEventListener('edunova-local-change',update);};
export const exists=async(name,field,value,excludeId=null)=>!!value&&rows(name).some(x=>x[field]===value&&x.id!==excludeId);
export const getById=async(name,id)=>rows(name).find(x=>x.id===id)||null;
export async function save(name,data,id=null){const store=readStore(),list=store[name]||[];const clean=Object.fromEntries(Object.entries(data).filter(([,v])=>v!==undefined&&v!==''));if(id){const index=list.findIndex(x=>x.id===id);if(index<0)throw new Error('Registro no encontrado.');list[index]={...list[index],...clean,updatedAt:new Date().toISOString()};}else{id=newId(name);list.push({id,...clean,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});}store[name]=list;writeStore(store);return id;}
export const setActive=(name,id,activo)=>save(name,{activo},id);
export async function setCurrentYear(id){const store=readStore();store.anios_academicos.forEach(x=>x.actual=x.id===id);writeStore(store);}
export const duplicateAssignment=async(d,id=null)=>rows('asignaciones').some(x=>x.id!==id&&x.anioId===d.anioId&&x.seccionId===d.seccionId&&x.cursoId===d.cursoId);
export const duplicateEnrollment=async(d,id=null)=>rows('matriculas').some(x=>x.id!==id&&x.estudianteId===d.estudianteId&&x.anioId===d.anioId);
const rosterRow=(m,s)=>({matriculaId:m.id,estudianteId:m.estudianteId,codigo:s.codigo||'',nombres:s.nombres||'',apellidos:s.apellidos||''});
export async function syncAssignmentRoster(assignment){const store=readStore(),enrolled=store.matriculas.filter(m=>m.anioId===assignment.anioId&&m.seccionId===assignment.seccionId&&m.estado==='Matriculado');store.rosters||={};store.rosters[assignment.id]=enrolled.map(m=>rosterRow(m,store.estudiantes.find(s=>s.id===m.estudianteId)||{}));writeStore(store);}
export async function syncEnrollmentRosters(matricula,student){const store=readStore();store.rosters||={};store.asignaciones.filter(a=>a.anioId===matricula.anioId&&a.seccionId===matricula.seccionId).forEach(a=>{const list=store.rosters[a.id]||[];const row=rosterRow(matricula,student),i=list.findIndex(x=>x.matriculaId===matricula.id);if(i<0)list.push(row);else list[i]=row;store.rosters[a.id]=list;});writeStore(store);}
