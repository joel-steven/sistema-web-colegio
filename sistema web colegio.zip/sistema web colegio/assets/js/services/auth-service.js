import { readStore } from '../data/local-store.js';
export const rolePaths = { administrador: '/admin/', profesor: '/profesor/', padre: '/padre/' };
const SESSION = 'edunova-local-session';
export async function login(email,password){const user=readStore().usuarios.find(x=>x.email.toLowerCase()===email.trim().toLowerCase()&&x.password===password&&x.activo!==false);if(!user)throw new Error('El correo o la contraseña no son correctos.');localStorage.setItem(SESSION,user.id);return user.rol;}
export async function resetPassword(){throw new Error('La recuperación de contraseña no está disponible en modo local.');}
export async function logout(){localStorage.removeItem(SESSION);location.assign('/');}
export function protectPage(requiredRole){return new Promise(resolve=>{const id=localStorage.getItem(SESSION),profile=readStore().usuarios.find(x=>x.id===id);if(!profile||!rolePaths[profile.rol])return location.assign('/');if(profile.rol!==requiredRole)return location.assign(rolePaths[profile.rol]);resolve({user:{uid:profile.id,email:profile.email},profile});});}
