// Configuración del proyecto Firebase "sistema-web-colegio".
// Las reglas de Firestore protegen los datos y permisos de acceso.
export const firebaseConfig = {
  apiKey: 'AIzaSyDLANVxwk1TW0pta6W42Z4Mapi83s-lzXY',
  authDomain: 'sistema-web-colegio.firebaseapp.com',
  databaseURL: 'https://sistema-web-colegio-default-rtdb.firebaseio.com',
  projectId: 'sistema-web-colegio',
  storageBucket: 'sistema-web-colegio.firebasestorage.app',
  messagingSenderId: '975142144378',
  appId: '1:975142144378:web:0735ff66c0e86fb671aec3',
  measurementId: 'G-FZ54RD3RWL'
};
